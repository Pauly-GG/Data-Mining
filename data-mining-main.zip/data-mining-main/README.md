# data-mining
Assignment work

Kazuki
https://www.kaggle.com/competitions/allstate-purchase-prediction-challenge/data
